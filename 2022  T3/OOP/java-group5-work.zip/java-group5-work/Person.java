class Person{
    String name;
    int age;
    String County_of_residence;
    int weight;
    String serialization;
    String county;

    public void myName(String name){
        System.out.print(name);
    }
    public void myAge(int age){
        System.out.print(age);
    }
    public void myCounty(String County_of_residence){
        System.out.print(County_of_residence);
    }
    public void myWeight(String weight){
        System.out.print(weight);
    }
}