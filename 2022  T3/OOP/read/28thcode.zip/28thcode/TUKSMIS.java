class TUKSMIS{
//properties

//create an entry point fo rthe JVM
static public void main(String args[]){
    //System.out.println("I am the Entry point class");

    //Logic to select what a user of the System wasnts to do
    
    User user1 = new User("Salesio",1,"dirUserName","stringPass");
    user1.printUserDetails();
    //admin1.login();
}

}