class NormalUser extends User{


}